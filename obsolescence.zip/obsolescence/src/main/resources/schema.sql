RUNSCRIPT FROM 'classpath:org/springframework/batch/core/schema-h2.sql';
